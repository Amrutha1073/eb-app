# Node.js AWS Elastic Beanstalk App

This is a simple Node.js app deployed on AWS Elastic Beanstalk.

## To Run Locally
